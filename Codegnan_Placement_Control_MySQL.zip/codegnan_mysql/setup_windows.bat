@echo off
setlocal
if not exist .env copy .env.example .env
call npm install
if errorlevel 1 exit /b 1
echo.
echo Next: run schema.sql in MySQL Workbench, edit .env with your MySQL password, then run npm start.
endlocal
