CREATE DATABASE IF NOT EXISTS codegnan_placement;
USE codegnan_placement;

CREATE TABLE IF NOT EXISTS students (
  id VARCHAR(30) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  branch VARCHAR(30) NOT NULL,
  batch VARCHAR(20) NOT NULL,
  cgpa DECIMAL(4,2) NOT NULL DEFAULT 0,
  backlogs INT NOT NULL DEFAULT 0,
  skills TEXT,
  resume VARCHAR(255),
  status ENUM('pending','approved') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS recruiters (
  id VARCHAR(30) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  company VARCHAR(150) NOT NULL,
  designation VARCHAR(120),
  status ENUM('pending','approved') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS drives (
  id VARCHAR(30) PRIMARY KEY,
  company VARCHAR(150) NOT NULL,
  role VARCHAR(150) NOT NULL,
  package VARCHAR(50),
  branch VARCHAR(150) NOT NULL DEFAULT 'ANY',
  cgpa_cutoff DECIMAL(4,2) NOT NULL DEFAULT 0,
  backlog_rule VARCHAR(20) NOT NULL DEFAULT 'no-active',
  deadline DATE NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  recruiter_name VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS applications (
  id VARCHAR(30) PRIMARY KEY,
  student_id VARCHAR(30) NOT NULL,
  drive_id VARCHAR(30) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'applied',
  round_history JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_student_drive (student_id, drive_id),
  CONSTRAINT fk_app_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_app_drive FOREIGN KEY (drive_id) REFERENCES drives(id) ON DELETE CASCADE
);
