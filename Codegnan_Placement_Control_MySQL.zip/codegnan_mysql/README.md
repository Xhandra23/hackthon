# Codegnan Placement Control + MySQL

This version adds a Node.js/Express backend and MySQL persistence to the existing HTML application.

## Architecture

Browser (HTML/CSS/JavaScript) -> Express API -> MySQL

The existing `getList()` / `setList()` calls now use `/api/...` instead of browser storage. Data is stored in four MySQL tables: `students`, `recruiters`, `drives`, and `applications`.

MySQL2 supports the Promise API and connection pools, which fits the async/await code used here. See the official MySQL2 documentation: https://sidorares.github.io/node-mysql2/docs

## Setup on Windows

1. Install Node.js and MySQL.
2. Open MySQL Workbench or the MySQL command line.
3. Run `schema.sql`.
4. Copy `.env.example` to `.env`.
5. Put your MySQL password in `.env`.
6. In this folder run:

```bash
npm install
npm start
```

7. Open `http://localhost:3000` in Chrome.
8. Test `http://localhost:3000/api/health`. It should return `ok: true`.

## Important

Do not put the MySQL password inside `index.html`. The browser talks only to the Express API; the server owns the database credentials.

The current UI's role login is still a demo-style flow. MySQL persistence is connected, but production authentication should be added separately with password hashing/session or token authentication.
