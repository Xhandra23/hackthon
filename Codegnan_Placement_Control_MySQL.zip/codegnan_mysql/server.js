require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'codegnan_placement',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

function json(value) {
  if (value == null) return [];
  if (typeof value === 'object') return value;
  try { return JSON.parse(value); } catch { return []; }
}

async function getList(key) {
  if (key === 'students') {
    const [rows] = await pool.query('SELECT id,name,branch,batch,cgpa,backlogs,skills,resume,status FROM students ORDER BY created_at');
    return rows;
  }
  if (key === 'recruiters') {
    const [rows] = await pool.query('SELECT id,name,company,designation,status FROM recruiters ORDER BY created_at');
    return rows;
  }
  if (key === 'drives') {
    const [rows] = await pool.query('SELECT id,company,role,package,branch,cgpa_cutoff AS cgpaCutoff,backlog_rule AS backlogRule,DATE_FORMAT(deadline, "%Y-%m-%d") AS deadline,status,recruiter_name AS recruiterName FROM drives ORDER BY created_at DESC');
    return rows;
  }
  if (key === 'applications') {
    const [rows] = await pool.query('SELECT id,student_id AS studentId,drive_id AS driveId,status,round_history AS roundHistory FROM applications ORDER BY created_at');
    return rows.map(r => ({...r, roundHistory: json(r.roundHistory)}));
  }
  throw Object.assign(new Error('Unknown data collection'), { status: 400 });
}

async function replaceList(key, value) {
  if (!Array.isArray(value)) throw Object.assign(new Error('Payload must be an array'), { status: 400 });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    if (key === 'students') {
      for (const s of value) {
        await conn.execute(`INSERT INTO students (id,name,branch,batch,cgpa,backlogs,skills,resume,status)
          VALUES (?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE name=VALUES(name),branch=VALUES(branch),batch=VALUES(batch),cgpa=VALUES(cgpa),backlogs=VALUES(backlogs),skills=VALUES(skills),resume=VALUES(resume),status=VALUES(status)`,
          [s.id,s.name,s.branch,s.batch,Number(s.cgpa)||0,Number(s.backlogs)||0,s.skills||'',s.resume||'—',s.status||'pending']);
      }
      const ids = value.map(s=>s.id); if (ids.length) await conn.query('DELETE FROM students WHERE id NOT IN (?)',[ids]);
      else await conn.query('DELETE FROM students');
    } else if (key === 'recruiters') {
      for (const r of value) {
        await conn.execute(`INSERT INTO recruiters (id,name,company,designation,status) VALUES (?,?,?,?,?)
          ON DUPLICATE KEY UPDATE name=VALUES(name),company=VALUES(company),designation=VALUES(designation),status=VALUES(status)`,
          [r.id,r.name,r.company||'Unnamed Co.',r.designation||'—',r.status||'pending']);
      }
      const ids=value.map(r=>r.id); if(ids.length) await conn.query('DELETE FROM recruiters WHERE id NOT IN (?)',[ids]); else await conn.query('DELETE FROM recruiters');
    } else if (key === 'drives') {
      for (const d of value) {
        const deadline = d.deadline && d.deadline !== 'TBD' ? d.deadline : null;
        await conn.execute(`INSERT INTO drives (id,company,role,package,branch,cgpa_cutoff,backlog_rule,deadline,status,recruiter_name)
          VALUES (?,?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE company=VALUES(company),role=VALUES(role),package=VALUES(package),branch=VALUES(branch),cgpa_cutoff=VALUES(cgpa_cutoff),backlog_rule=VALUES(backlog_rule),deadline=VALUES(deadline),status=VALUES(status),recruiter_name=VALUES(recruiter_name)`,
          [d.id,d.company,d.role,d.package||'—',d.branch||'ANY',Number(d.cgpaCutoff)||0,d.backlogRule||'no-active',deadline,d.status||'open',d.recruiterName||'TBD']);
      }
      const ids=value.map(d=>d.id); if(ids.length) await conn.query('DELETE FROM drives WHERE id NOT IN (?)',[ids]); else await conn.query('DELETE FROM drives');
    } else if (key === 'applications') {
      for (const a of value) {
        await conn.execute(`INSERT INTO applications (id,student_id,drive_id,status,round_history) VALUES (?,?,?,?,?)
          ON DUPLICATE KEY UPDATE student_id=VALUES(student_id),drive_id=VALUES(drive_id),status=VALUES(status),round_history=VALUES(round_history)`,
          [a.id,a.studentId,a.driveId,a.status||'applied',JSON.stringify(a.roundHistory||['Applied'])]);
      }
      const ids=value.map(a=>a.id); if(ids.length) await conn.query('DELETE FROM applications WHERE id NOT IN (?)',[ids]); else await conn.query('DELETE FROM applications');
    } else throw Object.assign(new Error('Unknown data collection'), {status:400});
    await conn.commit();
  } catch (e) { await conn.rollback(); throw e; }
  finally { conn.release(); }
}

app.get('/api/health', async (req,res)=>{
  try { await pool.query('SELECT 1'); res.json({ok:true,database:process.env.DB_NAME||'codegnan_placement'}); }
  catch(e) { res.status(500).json({ok:false,error:e.message}); }
});

app.get('/api/:key', async (req,res)=>{
  try { res.json(await getList(req.params.key)); }
  catch(e) { res.status(e.status||500).json({error:e.message}); }
});

app.put('/api/:key', async (req,res)=>{
  try { await replaceList(req.params.key, req.body); res.json({ok:true}); }
  catch(e) { console.error(e); res.status(e.status||500).json({error:e.message}); }
});

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

const port=Number(process.env.PORT||3000);
app.listen(port, async()=>{
  try { await pool.query('SELECT 1'); console.log(`Server running: http://localhost:${port}`); console.log('MySQL connection: OK'); }
  catch(e){ console.error('MySQL connection failed:',e.message); console.error('Check .env and make sure MySQL is running.'); }
});
